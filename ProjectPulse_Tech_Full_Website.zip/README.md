# ProjectPulse Technologies — Next.js App Router

Install & run:
1) npm install
2) npm run dev

Deploy on Vercel:
1) Push this folder to your GitHub repo
2) Import the repo in Vercel (Next.js preset)
3) Add your domain projectpulse.systems in Vercel → Settings → Domains
4) Add DNS records in Squarespace as Vercel instructs (A @ 76.76.21.21, CNAME www cname.vercel-dns.com)
5) Redeploy & verify SSL

CTA buttons use: mailto:natemun@gmail.com
Footer shows: Email us + Office: Philadelphia, PA
