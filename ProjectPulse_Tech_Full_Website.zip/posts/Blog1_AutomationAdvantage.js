export default function BlogPostAutomationAdvantage() {
  return (
    <div className="min-h-screen bg-[#0A0F1F] text-white">
      <section className="relative overflow-hidden py-24">
        <div className="absolute inset-0 opacity-30 bg-gradient-to-r from-violet-600 via-fuchsia-500 to-cyan-400" />
        <div className="relative max-w-5xl mx-auto px-6">
          <p className="uppercase tracking-widest text-cyan-200/80 text-sm mb-3">Business Process Automation</p>
          <h1 className="text-4xl md:text-6xl font-extrabold">The Automation Advantage: How Businesses Save 30% of Time</h1>
          <p className="mt-5 text-lg text-cyan-100/90 max-w-3xl">Manual work slows growth. Smart systems unlock it.</p>
        </div>
      </section>
      <article className="max-w-4xl mx-auto px-6 space-y-8">
        <p>At ProjectPulse, teams routinely reduce operational hours by up to 30%, freeing talent to focus on strategy and innovation.</p>
      </article>
      <section className="text-center py-16">
        <a href="mailto:natemun@gmail.com" className="bg-white text-violet-700 font-semibold px-6 py-3 rounded-2xl">Book a Consultation</a>
      </section>
    </div>
  );
}