export default function BlogPostPMSystem() {
  return (
    <div className="min-h-screen bg-[#0A0F1F] text-white">
      <section className="relative overflow-hidden py-24">
        <div className="absolute inset-0 opacity-30 bg-gradient-to-r from-violet-600 via-fuchsia-500 to-cyan-400" />
        <div className="relative max-w-5xl mx-auto px-6">
          <p className="uppercase tracking-widest text-cyan-200/80 text-sm mb-3">Project Management Systems</p>
          <h1 className="text-4xl md:text-6xl font-extrabold">How to Build a PM System That Actually Delivers Results</h1>
          <p className="mt-5 text-lg text-cyan-100/90 max-w-3xl">Systems fail when tools replace strategy. Fix the roots.</p>
        </div>
      </section>
      <article className="max-w-4xl mx-auto px-6 space-y-8">
        <p>Align people, process, and technology into a single integrated system — one that actually works.</p>
      </article>
      <section className="text-center py-16">
        <a href="mailto:natemun@gmail.com" className="bg-white text-violet-700 font-semibold px-6 py-3 rounded-2xl">Book a Consultation</a>
      </section>
    </div>
  );
}